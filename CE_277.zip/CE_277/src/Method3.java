public class Method3 {
    public static void main(String[] args) {
        int a=45;
        int b=60;

        System.out.println(a+" +"+b+"is "+a+b);



    }
}
